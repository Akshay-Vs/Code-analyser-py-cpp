#include "stdio.h"

int main(int a, int b) {
    return a+b;
}
def add_two_numbers(a:int, b:int)->int:
    return a+b